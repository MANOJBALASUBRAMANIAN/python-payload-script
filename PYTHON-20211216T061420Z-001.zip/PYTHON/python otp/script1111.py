import sys

orig_stdout = sys.stdout
f = open('out.txt', 'w')
sys.stdout = f

for i in range(1,99999999):('{num:02d}'.format(num=i))
    

sys.stdout = orig_stdout
f.close()