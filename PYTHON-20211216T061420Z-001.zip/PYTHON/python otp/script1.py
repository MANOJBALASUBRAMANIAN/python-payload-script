a, b, c = 1, 10, 100
for val in [a, b, c]:
    print(f'{val:02}')