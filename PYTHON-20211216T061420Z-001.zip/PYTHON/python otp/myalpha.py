# Function to find permutations of a given string 
from itertools import permutations 

def allPermutations(str): 
	
	# Get all permutations of string '' 
	permList = permutations(str) 

	# print all permutations 
	for perm in list(permList): 
		print (''.join(perm)) 
		
# Driver program 
if __name__ == "__main__": 
	str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'
	allPermutations(str) 

[A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,]



def predicate(seq):
    return len(set(type(item) for item in seq))) > 1
    values = list(string.letters) + range(10)
    mixed_letter_int_combinations = filter(predicate, combinations(values, 4))