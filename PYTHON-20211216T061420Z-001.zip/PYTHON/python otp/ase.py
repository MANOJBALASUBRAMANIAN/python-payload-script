def perm(string):
   res=[]
   for j in range(4,len(string)):
       if(len(string)>1):
           for i in perm(string[1:]):
               res.append(string[0]+i)
       else:
           return [string];
       string=string[1:]+string[0];
   return res;l=set(perm("abcde"))