import sys

orig_stdout = sys.stdout
f = open('out.txt', 'w')
sys.stdout = f

for i in range(0,10000000):
    print('%07d' %i)

sys.stdout = orig_stdout
f.close()