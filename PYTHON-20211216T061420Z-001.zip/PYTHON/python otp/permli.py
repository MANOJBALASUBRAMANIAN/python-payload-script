
# A Python program to print all  
# permutations of given length 
from itertools import permutations 
  
# Get all permutations of length 2 
# and length 2 
perm = permutations([0,1,2,3,4,5,6,7,8,9,], 2) 
  
# Print the obtained permutations 
for i in list(perm): 
    print (i) 