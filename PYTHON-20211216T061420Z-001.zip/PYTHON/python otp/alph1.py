def splitString(str): 
  
    alpha = "" 
    num = "" 
    special = "" 
    for i in range(len(str)): 
        if (str[i].isdigit()): 
            num = num+ str[i] 
        elif((str[i] >= 'A' and str[i] <= 'Z') or
             (str[i] >= 'a' and str[i] <= 'z')): 
            alpha += str[i] 
        else: 
            special += str[i] 
  
    print(alpha) 
    print(num ) 
    print(special) 




set[] = {'a', 'b'}, k = 3




The string constants may be what you want. (docs)

import string
string.ascii_uppercase
'ABCDEFGHIJKLMNOPQRSTUVWXYZ'



string.printable


# Function which returns subset or r length from n 
from itertools import combinations 
  
def rSubset(arr, r): 
  
    # return list of all subsets of length r 
    # to deal with duplicate subsets use  
    # set(list(combinations(arr, r))) 
    return list(combinations(arr, r)) 
  
# Driver Function 
if __name__ == "__main__": 
    arr = [1, 2, 3, 4] 
    r = 2
    print rSubset(arr, r) 

import sys
from itertools import permutations 

inputstr = sys.argv[1].upper()
print inputstr

perms = (p for p in permutations(inputstr))
for p in perms:
    print ''.join(p)