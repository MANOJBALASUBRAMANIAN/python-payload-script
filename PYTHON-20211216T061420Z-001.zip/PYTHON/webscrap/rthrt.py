# imported the requests library 
import requests 
url = ""
r = requests.get(url) # create HTTP response object 
with open("python_logo.png",'wb') as f: 
f.write(r.content) 