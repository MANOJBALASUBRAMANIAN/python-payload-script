import os
from bs4 import BeautifulSoup
# Python 3.x
from urllib.request import urlopen, urlretrieve

URL = "https://www.owasp.org/index.php/OWASP_Testing_Guide_v4_Table_of_Contents"
OUTPUT_DIR = 'E:\New folder' 

u = urlopen(URL)
try:
    html = u.read().decode('utf-8')
finally:
    u.close()

soup = BeautifulSoup(html, "html.parser")
for link in soup.select('<a href="/'): # or a[href*="shareedb/0"]
    href = link.get('href')
    if not any(href.endswith(/) for / in ['/']):
        continue

    filename = os.path.join(href)

    # We need a https:// URL for this site
    # href = href.replace('http://','https://')

    print("Downloading %s to %s..." % (href, filename) )
    urlretrieve(href, filename)
    print("Done.")